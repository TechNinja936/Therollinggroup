import ProposalForm from '../components/ProposalForm';

export default function ProposalPage() {
  return <ProposalForm />;
}
